package com.cg.emp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;
@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException{
		TypedQuery<Employee> query= entityManager.createQuery("from Employee order by id",Employee.class);
		return query.getResultList();
	}
	
	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		
		try{
			Employee emp=entityManager.find(Employee.class, id);
		entityManager.remove(emp);
		return getAllEmployees();
		}
		catch (EmployeeException e) {
			throw new EmployeeException(e.getMessage());
		}
	}
	@Override
public List<Employee> addEmployee(Employee emp) throws EmployeeException{
entityManager.persist(emp);
	return getAllEmployees();
	
}
	@Override
	public Employee getEmployeeById(int id) throws EmployeeException{
		
		return entityManager.find(Employee.class, id);
		
	}
	@Override
public	List<Employee> updateEmployee(Employee emp) throws EmployeeException{
		entityManager.merge(emp);
		return getAllEmployees();
}
}