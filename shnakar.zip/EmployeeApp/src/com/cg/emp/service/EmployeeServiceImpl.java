package com.cg.emp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.emp.bean.Employee;
import com.cg.emp.dao.EmployeeDao;
import com.cg.emp.exception.EmployeeException;


@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
@Autowired
EmployeeDao employeeDao;
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.getAllEmployees();
	}
	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.deleteEmployee(id);
	}
	@Override
public List<Employee> addEmployee(Employee emp) throws EmployeeException{
	return employeeDao.addEmployee(emp);

}
@Override
	public 	Employee getEmployeeById(int id) throws EmployeeException{
		return employeeDao.getEmployeeById(id);

}
@Override
public List<Employee> updateEmployee(Employee emp) throws EmployeeException{
	return employeeDao.updateEmployee(emp);
}
}