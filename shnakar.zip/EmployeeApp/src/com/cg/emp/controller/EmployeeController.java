package com.cg.emp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping("/")
public ModelAndView home() {
ModelAndView mv;
try {
	List<Employee> employees=employeeService.getAllEmployees();
	mv=new ModelAndView("index");
	mv.addObject("employees", employees);
	return mv;
}
		catch (EmployeeException e) {
			mv=new ModelAndView("error");
			mv.addObject("err", e);
			return mv;
		}
	
}
	@RequestMapping("/delete")

	public ModelAndView deleteEmployee(@RequestParam int id) {
		ModelAndView mv;
			
		 try {
			List<Employee> employees= employeeService.deleteEmployee(id);
			mv=new ModelAndView("index");
			mv.addObject("employees", employees);
		 return mv;
		 } catch (EmployeeException e) {
			mv=new ModelAndView("error");
			mv.addObject("err",e);
			return mv;
		}
		 
		
	}
	@RequestMapping("/addEmployee")
	public String showAddForm(Model model) {
		model.addAttribute("employee",new Employee());
		return "add";
	}
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ModelAndView addEmployee(@Valid @ModelAttribute Employee emp, BindingResult result) {
		ModelAndView mv;
		if(result.hasErrors()) {
			mv=new ModelAndView("add");
			return mv;
		}
		try {
		List<Employee>employees=employeeService.addEmployee(emp);
		mv=new ModelAndView("index");
		mv.addObject("employees", employees);
		return mv;
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
		mv= new ModelAndView("error");
		mv.addObject("err",e);
		
		}
		return mv;
			}
	@RequestMapping("/update")
	public String updateEmployee(@RequestParam int id, Model model) {
		try {
		Employee emp=	employeeService.getEmployeeById(id);
			model.addAttribute("employee",emp);
			return "update";
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			model.addAttribute("err",e);
			return "error";
		}
			}
	@RequestMapping(value="/updateEmployee" )
	public ModelAndView saveEmployee(@ModelAttribute Employee emp) {
		ModelAndView mv;
		try {
			List<Employee> employees= employeeService.updateEmployee(emp);
			mv=new ModelAndView("index");
			mv.addObject("employees", employees);
		} catch (EmployeeException e) {
			mv= new ModelAndView("error");
			mv.addObject("err",e);
		}
		return mv;
	}
	
}
